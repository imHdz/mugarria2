

public class Main {
    public static void main(String[] args) {
        Mugarria2 v2 = new Mugarria2();
        v2.setVisible(true);
    }
}
