import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


    public class Mugarria2 extends JFrame implements ActionListener {
        String path="c:\\datos\\";
        private JButton b1,b2;
        private JPanel panelLeft,panelRight,panelBottom;
        private JComboBox<String> combo;
        private JTextArea area;

        public Mugarria2(){

            this.setDefaultCloseOperation(EXIT_ON_CLOSE);
            this.setTitle("NosEqEPonEr");
            this.setPreferredSize(new Dimension(500,500));
            this.setLayout(new BorderLayout());
            this.pack();
            this.setLocationRelativeTo(null);

            panelLeft = new JPanel(new FlowLayout());
            String[] files = {"box.txt","muaythai.txt"};
            combo = new JComboBox(files);
            b1 = new JButton("Clear");
            panelLeft.add(combo);
            panelLeft.add(b1);
            this.add(panelLeft,BorderLayout.WEST);


            panelRight = new JPanel(new GridLayout(0,1));
            area = new JTextArea(6,11);
            JScrollPane scroll = new JScrollPane(area,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
            scroll.createVerticalScrollBar();
            panelRight.add(scroll);
            this.add(panelRight,BorderLayout.EAST);

            panelBottom = new JPanel();
            b2 = new JButton("Close");
            panelBottom.add(b2);
            this.add(panelBottom,BorderLayout.SOUTH);


            combo.addActionListener(this);
            b1.addActionListener(this);
            b2.addActionListener(this);
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource().equals(combo)){
                String file = (String) combo.getSelectedItem();
                try {
                    BufferedReader reader = new BufferedReader(new FileReader(path+file));
                    String text = "";
                    String line = reader.readLine();
                    while (line != null) {
                        text += line + "\n";
                        line = reader.readLine();
                    }
                    reader.close();
                    area.setText(text);
                }
                catch (IOException exception){
                    exception.printStackTrace();
                    System.out.println("No se ha encontrado el archivo " +file);
                }
            }
            if(e.getSource().equals(b2)) {
                dispose();
            }
            if(e.getSource().equals(b1)){
                area.setText("");
            }
        }
    }

